import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-breed-remoto',
  templateUrl: './breed-remoto.component.html',
  styleUrls: ['./breed-remoto.component.css']
})
export class BreedRemotoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
