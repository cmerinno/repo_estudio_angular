export class Breed {
    constructor(
        public raza: string,
        public imagen: string

    ) { }
}
